# Blue Turtle Spiral Art (Vibrant Blue & Slow Animation)

A lightweight Python project that creates an animated, multi-arm vibrant blue spiral geometric pattern using Python's built-in `turtle` graphics library.

## Project Structure
- **Folder Name:** `blue_turtle_spiral`
- **Main Script:** `spiral_art.py`
- **Documentation:** `README.md`

## Requirements
- Python 3.x (No external libraries required; `turtle`, `math`, and `time` are built-in).

## How to Run
1. Open your terminal or command prompt.
2. Navigate to the `blue_turtle_spiral` folder.
3. Run the script using the following command:
   ```bash
   python spiral_art.py